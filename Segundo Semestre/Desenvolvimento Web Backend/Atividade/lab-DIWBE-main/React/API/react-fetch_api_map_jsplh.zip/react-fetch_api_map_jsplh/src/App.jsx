import { useState, useEffect } from "react";

// Components
import Header from "./components/header";
import Footer from "./components/footer";
import PhotoCard from "./components/photoCard";

const App = () => {
  const [photos, setPhotos] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Buscando apenas as primeiras 20 fotos para carregar rápido
    fetch('https://jsonplaceholder.typicode.com/photos?_limit=20')
      .then(response => {
        if (!response.ok) {
          throw new Error('Erro na requisição: ' + response.status);
        }
        return response.json();
      })
      .then(data => {
        setPhotos(data);
        setLoading(false);
      })
      .catch(error => {
        console.error('Erro ao carregar fotos:', error);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <>
        <Header />
        <main style={{ padding: '40px', textAlign: 'center' }}>
          <h2>Carregando galeria...</h2>
        </main>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Header />
      
      <main style={{ padding: '24px', maxWidth: '1200px', margin: '0 auto' }}>
        <h1 style={{ marginBottom: '24px', color: '#0f172a' }}>Galeria de Fotos</h1>
        
        {/* Container Grid Responsivo */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))',
          gap: '20px'
        }}>
          {photos.map((photo) => (
            <PhotoCard
              key={photo.id}
              title={photo.title}
              thumbnailUrl={photo.thumbnailUrl}
              url={photo.url}
              label="Ver imagem em HD"
            />
          ))}
        </div>
      </main>

      <Footer />
    </>
  );
};

export default App;