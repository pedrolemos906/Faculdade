const Footer = () => {

    return(
        <footer>
            <h5>Desenvolvido na disciplina de Desenvolvimento de Aplicações Móveis e Distribuídas da PUC Minas - 2026</h5>
        </footer>
    );

}

export default Footer;