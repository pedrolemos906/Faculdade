import React from 'react';
import './photoCard.css';

const PhotoCard = ({ title, url, thumbnailUrl, label = "Ver foto completa" }) => {
  return (
    <div className="photo-card">
      <img 
        src={thumbnailUrl} 
        alt={title} 
        className="photo-card-image" 
        loading="lazy" 
      />
      <div className="photo-card-content">
        <h3 className="photo-card-title">{title}</h3>
        <a 
          href={url} 
          target="_blank" 
          rel="noopener noreferrer" 
          className="photo-card-link"
        >
          <span>{label}</span>
          <span className="photo-card-arrow">&rarr;</span>
        </a>
      </div>
    </div>
  );
}

export default PhotoCard;