import './card.css';

const Card = ({ name, url, label = "Acessar link" }) => {
  return (
    <div className="card">
      <h3 className="card-title">{name}</h3>
      <a 
        href={url} 
        target="_blank" 
        rel="noopener noreferrer" 
        className="card-link"
      >
        <span>{label}</span>
        <span className="card-arrow">&rarr;</span>
      </a>
    </div>
  );
}

export default Card;