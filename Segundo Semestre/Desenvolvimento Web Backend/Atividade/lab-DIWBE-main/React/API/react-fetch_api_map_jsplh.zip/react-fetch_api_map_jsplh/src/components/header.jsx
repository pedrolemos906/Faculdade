const Header = () => {

    return(
        <header>
            <h2>Galeria de Fotos - JSONPlaceholder</h2>
        </header>
    );

}

export default Header;