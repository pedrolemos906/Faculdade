import { useEffect, useState } from "react";

function App() {

  const [tarefas, setTarefas] = useState([]);
  const [titulo, setTitulo] = useState("");

  useEffect(() => {
    carregarTarefas();
  }, []);

  function carregarTarefas() {

    fetch("http://localhost:3000/tarefas")

      .then(resposta => {

        if (!resposta.ok) {
          throw new Error("Erro ao buscar tarefas");
        }

        return resposta.json();

      })

      .then(dados => {
        setTarefas(dados);
      })

      .catch(erro => {
        console.error(erro);
      });
  }

  function cadastrarTarefa(event) {

    event.preventDefault();

    if (titulo.trim() === "") {
      alert("Digite uma tarefa");
      return;
    }

    fetch("http://localhost:3000/tarefas", {

      method: "POST",

      headers: {
        "Content-Type": "application/json"
      },

      body: JSON.stringify({

        titulo: titulo,

        status: "Pendente"

      })

    })

      .then(resposta => {

        if (!resposta.ok) {
          throw new Error("Erro ao cadastrar tarefa");
        }

        return resposta.json();

      })

      .then(() => {

        setTitulo("");

        carregarTarefas();

      })

      .catch(erro => {

        console.error(erro);

      });
  }

  function concluirTarefa(tarefa) {

    fetch(`http://localhost:3000/tarefas/${tarefa.id}`, {

      method: "PUT",

      headers: {
        "Content-Type": "application/json"
      },

      body: JSON.stringify({

        titulo: tarefa.titulo,

        status: "Concluída"

      })

    })

      .then(resposta => {

        if (!resposta.ok) {
          throw new Error("Erro ao atualizar tarefa");
        }

        return resposta.json();

      })

      .then(() => {

        carregarTarefas();

      })

      .catch(erro => {

        console.error(erro);

      });
  }

  function excluirTarefa(id) {

    fetch(`http://localhost:3000/tarefas/${id}`, {

      method: "DELETE"

    })

      .then(resposta => {

        if (!resposta.ok) {
          throw new Error("Erro ao excluir tarefa");
        }

        carregarTarefas();

      })

      .catch(erro => {

        console.error(erro);

      });
  }

  return (

    <div>

      <h1>Lista de Tarefas</h1>

      <form onSubmit={cadastrarTarefa}>

        <input
          type="text"
          placeholder="Digite uma tarefa"
          value={titulo}
          onChange={event => setTitulo(event.target.value)}
        />

        <button type="submit">
          Adicionar
        </button>

      </form>

      <hr />

      {tarefas.map(tarefa => (

        <div key={tarefa.id}>

          <h3>
            {tarefa.titulo}
          </h3>

          <p>
            ID: {tarefa.id}
          </p>

          <p>
            Status: {tarefa.status}
          </p>

          {tarefa.status === "Pendente" && (

            <button
              onClick={() => concluirTarefa(tarefa)}
            >
              Concluir
            </button>

          )}

          <button
            onClick={() => excluirTarefa(tarefa.id)}
          >
            Excluir
          </button>

          <hr />

        </div>

      ))}

    </div>
  );
}

export default App;