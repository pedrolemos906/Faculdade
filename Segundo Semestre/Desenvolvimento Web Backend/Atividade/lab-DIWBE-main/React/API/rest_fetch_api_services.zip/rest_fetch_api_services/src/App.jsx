import { useEffect, useState } from "react";

import {
  listarTarefas,
  criarTarefa,
  atualizarTarefa,
  excluirTarefa
} from "./services/tarefaService";


function App() {

  const [tarefas, setTarefas] = useState([]);

  const [titulo, setTitulo] = useState("");


  useEffect(() => {

    carregarTarefas();

  }, []);


  async function carregarTarefas() {

    try {

      const dados = await listarTarefas();

      setTarefas(dados);

    } catch (erro) {

      console.error(erro);

    }

  }


  async function cadastrarTarefa(event) {

    event.preventDefault();

    if (titulo.trim() === "") {

      alert("Digite uma tarefa");

      return;
    }

    try {

      await criarTarefa(titulo);

      setTitulo("");

      carregarTarefas();

    } catch (erro) {

      console.error(erro);

    }

  }


  async function concluirTarefa(tarefa) {

    try {

      await atualizarTarefa({

        ...tarefa,

        status: "Concluída"

      });

      carregarTarefas();

    } catch (erro) {

      console.error(erro);

    }

  }


  async function excluir(id) {

    try {

      await excluirTarefa(id);

      carregarTarefas();

    } catch (erro) {

      console.error(erro);

    }

  }


  return (

    <div>

      <h1>Lista de Tarefas</h1>


      <form onSubmit={cadastrarTarefa}>

        <input
          type="text"
          placeholder="Digite uma tarefa"
          value={titulo}
          onChange={(event) =>
            setTitulo(event.target.value)
          }
        />

        <button type="submit">
          Adicionar
        </button>

      </form>


      <hr />


      {tarefas.map(tarefa => (

        <div key={tarefa.id}>

          <h3>
            {tarefa.titulo}
          </h3>

          <p>
            ID: {tarefa.id}
          </p>

          <p>
            Status: {tarefa.status}
          </p>


          {tarefa.status === "Pendente" && (

            <button
              onClick={() => concluirTarefa(tarefa)}
            >
              Concluir
            </button>

          )}


          <button
            onClick={() => excluir(tarefa.id)}
          >
            Excluir
          </button>


          <hr />

        </div>

      ))}

    </div>

  );

}

export default App;