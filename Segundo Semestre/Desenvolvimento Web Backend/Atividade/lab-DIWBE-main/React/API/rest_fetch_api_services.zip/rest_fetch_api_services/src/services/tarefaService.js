const API_URL = "http://localhost:3000/tarefas";


export async function listarTarefas() {

  const resposta = await fetch(API_URL);

  if (!resposta.ok) {
    throw new Error("Erro ao buscar tarefas");
  }

  return await resposta.json();
}


export async function criarTarefa(titulo) {

  const resposta = await fetch(API_URL, {

    method: "POST",

    headers: {
      "Content-Type": "application/json"
    },

    body: JSON.stringify({
      titulo: titulo,
      status: "Pendente"
    })

  });

  if (!resposta.ok) {
    throw new Error("Erro ao cadastrar tarefa");
  }

  return await resposta.json();
}


export async function atualizarTarefa(tarefa) {

  const resposta = await fetch(`${API_URL}/${tarefa.id}`, {

    method: "PUT",

    headers: {
      "Content-Type": "application/json"
    },

    body: JSON.stringify({
      titulo: tarefa.titulo,
      status: tarefa.status
    })

  });

  if (!resposta.ok) {
    throw new Error("Erro ao atualizar tarefa");
  }

  return await resposta.json();
}


export async function excluirTarefa(id) {

  const resposta = await fetch(`${API_URL}/${id}`, {

    method: "DELETE"

  });

  if (!resposta.ok) {
    throw new Error("Erro ao excluir tarefa");
  }

  return true;
}