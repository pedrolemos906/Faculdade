import { useEffect, useState } from 'react';
import { tarefaService } from './services/api';

export default function App() {
  const [tarefas, setTarefas] = useState([]);
  const [novaDescricao, setNovaDescricao] = useState('');

  // Busca inicial das tarefas (READ)
  useEffect(() => {
    carregarTarefas();
  }, []);

  const carregarTarefas = async () => {
    try {
      const dados = await tarefaService.listar();
      setTarefas(dados);
    } catch (erro) {
      console.error(erro);
    }
  };

  const handleCriar = async (e) => {
    e.preventDefault();
    if (!novaDescricao.trim()) return;

    try {
      const tarefaCriada = await tarefaService.criar(novaDescricao);
      setTarefas((prev) => [...prev, tarefaCriada]);
      setNovaDescricao('');
    } catch (erro) {
      console.error(erro);
    }
  };

  const handleAlternarStatus = async (id, statusAtual) => {
    try {
      const tarefaAtualizada = await tarefaService.alternarStatus(id, statusAtual);
      setTarefas((prev) =>
        prev.map((t) => (t.id === id ? tarefaAtualizada : t))
      );
    } catch (erro) {
      console.error(erro);
    }
  };

  const handleDeletar = async (id) => {
    try {
      await tarefaService.deletar(id);
      setTarefas((prev) => prev.filter((t) => t.id !== id));
    } catch (erro) {
      console.error(erro);
    }
  };

  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif', maxWidth: '500px' }}>
      <h1>Lista de Tarefas</h1>

      <form onSubmit={handleCriar} style={{ display: 'flex', gap: '8px', marginBottom: '1rem' }}>
        <input
          type="text"
          placeholder="Nova tarefa..."
          value={novaDescricao}
          onChange={(e) => setNovaDescricao(e.target.value)}
          style={{ flex: 1, padding: '8px' }}
        />
        <button type="submit">Adicionar</button>
      </form>

      <ul style={{ listStyle: 'none', padding: 0 }}>
        {tarefas.map((tarefa) => (
          <li
            key={tarefa.id}
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-[#between]',
              padding: '8px 0',
              borderBottom: '1px solid #ccc'
            }}
          >
            <span
              onClick={() => handleAlternarStatus(tarefa.id, tarefa.concluida)}
              style={{
                cursor: 'pointer',
                textDecoration: tarefa.concluida ? 'line-through' : 'none',
                color: tarefa.concluida ? '#888' : '#000'
              }}
            >
              {tarefa.concluida ? '☑ ' : '☐ '} {tarefa.descricao}
            </span>
            <button onClick={() => handleDeletar(tarefa.id)}>Excluir</button>
          </li>
        ))}
      </ul>
    </div>
  );
}