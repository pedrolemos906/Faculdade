const BASE_URL = 'http://localhost:3000/tarefas';

export const tarefaService = {
  // READ (GET) - Lista todas as tarefas
  async listar() {
    const response = await fetch(BASE_URL);
    if (!response.ok) throw new Error('Erro ao buscar tarefas.');
    return response.json();
  },

  // CREATE (POST) - Adiciona uma nova tarefa
  async criar(descricao) {
    const novaTarefa = {
      descricao,
      concluida: false
    };

    const response = await fetch(BASE_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(novaTarefa)
    });

    if (!response.ok) throw new Error('Erro ao criar tarefa.');
    return response.json();
  },

  // UPDATE (PATCH) - Atualiza apenas o status de conclusão
  async alternarStatus(id, statusAtual) {
    const response = await fetch(`${BASE_URL}/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ concluida: !statusAtual })
    });

    if (!response.ok) throw new Error('Erro ao atualizar tarefa.');
    return response.json();
  },

  // DELETE (DELETE) - Remove uma tarefa pelo ID
  async deletar(id) {
    const response = await fetch(`${BASE_URL}/${id}`, {
      method: 'DELETE'
    });

    if (!response.ok) throw new Error('Erro ao deletar tarefa.');
    return response.json();
  }
};